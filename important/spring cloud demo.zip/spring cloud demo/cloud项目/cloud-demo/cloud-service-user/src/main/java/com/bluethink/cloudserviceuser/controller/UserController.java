package com.bluethink.cloudserviceuser.controller;

import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.model.User;
import com.bluethink.cloudserviceuser.service.UserService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
@RestController
@RequestMapping(value="/user")
@CrossOrigin
public class UserController {
    
    @Autowired
    UserService userService;

    /**
     * 添加用户
     */
    
    @PostMapping("/create")
    public Integer create(@RequestBody User user)  {
        if(userService.save(user)) {
            int userId = user.getId();
            return userId;
        }
        return null;
    }
    
    /**
     * 登陆
     * @param username
     * @param password
     * @return
     */
    @PostMapping("/login")
    public String login(@RequestParam("username") String username,@RequestParam("password") String password) {
        return userService.login(username,password);
    }


    /**
     * 获取用户
     * @
     */
    @PostMapping("/query")
    public PageInfo<User> query(@RequestBody UserFilter userFilter)  {

        PageInfo<User> obj = userService.query(userFilter);
        return obj;
    }

}
