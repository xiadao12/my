package com.bluethink.cloudserviceuser.mapper;

import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Mapper
public interface UserMapper {
    /**
     * 新增用户
     * @param user
     */
    public Integer save(User user)  ;
    
    /**
     * 查询用户
     * @return
     * @
     */
    public List<User> query(@Param("userFilter") UserFilter userFilter) ;

    /**
     * 验证密码
     * @return
     * @
     */
    public Integer verifyPassword(@Param("username") String username, @Param("password") String password) ;
    
}
