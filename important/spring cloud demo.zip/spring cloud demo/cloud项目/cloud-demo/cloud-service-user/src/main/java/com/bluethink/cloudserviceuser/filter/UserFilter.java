package com.bluethink.cloudserviceuser.filter;

import java.util.HashSet;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/12设计并构建初始版本v1.0.0
 */
public class UserFilter {
    private String token;
    private HashSet<Integer> ids;
    private String username;
    private String nickName;
    private int pageNum = 0;
    private int pageSize = 0;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public HashSet<Integer> getIds() {
        return ids;
    }

    public void setIds(HashSet<Integer> ids) {
        this.ids = ids;
    }
}
