package com.bluethink.cloudserviceuser.service.impl;

import com.bluethink.cloudserviceuser.feign.CommonFeign;
import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.mapper.UserMapper;
import com.bluethink.cloudserviceuser.model.User;
import com.bluethink.cloudserviceuser.service.UserService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private CommonFeign commonFeign;

    @Override
    public Boolean save(User user)  {

        Integer userId = userMapper.save(user);
        if(userId != null){
            return true;
        }
        return false;
    }

    @Override
    public PageInfo<User> query(UserFilter userFilter)  {

        PageHelper.startPage(userFilter.getPageNum(),userFilter.getPageSize());

        List<User> userList = userMapper.query(userFilter);
        Page<User> page = (Page<User>)userList;

        PageInfo pageInfo = new PageInfo(page);

        return pageInfo;

    }

    @Override
    public String login(String username,String password)  {
        //先判断用户名密码是否正确
        Integer userId = userMapper.verifyPassword(username,password);
        if(userId != null){
            String token = commonFeign.tokenCreate(userId);
            return token;
        }
        return null;
    }

}
