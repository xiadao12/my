package com.bluethink.cloudserviceuser.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/13设计并构建初始版本v1.0.0
 */
@FeignClient(value = "service-common")
public interface CommonFeign {
    /**
     * 生成Token
     */
    @PostMapping(value="/token/create")
    public String tokenCreate(@RequestParam("userId") Integer userId);

    /**
     * 根据token获取用户id
     */
    @PostMapping(value="/token/getUserId")
    public Integer tokenGetUserId(@RequestParam("token") String token);

    /**
     * 验证令牌
     */
    @PostMapping(value="/token/verify")
    public Integer tokenVerify(@RequestParam("token") String token);

}
