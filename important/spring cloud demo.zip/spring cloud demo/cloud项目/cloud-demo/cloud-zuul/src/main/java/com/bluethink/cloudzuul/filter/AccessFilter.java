package com.bluethink.cloudzuul.filter;

import com.bluethink.cloudzuul.feign.CommonFeign;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.Set;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/13设计并构建初始版本v1.0.0
 */
@Component
public class AccessFilter extends ZuulFilter {

    @Autowired
    private CommonFeign commonFeign;

    @Value("${prepath}")
    private String prepath;

    @Override
    public String filterType() {
        return "pre";
    }

    @Override
    public int filterOrder() {
        return 0;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() throws ZuulException {
        RequestContext requestContext = RequestContext.getCurrentContext();
        HttpServletRequest httpServletRequest = requestContext.getRequest();

        //过滤白名单
        Set<String> filterPath = new HashSet<>();
        filterPath.add(prepath + "/user/login");
        filterPath.add(prepath + "/plugin/query");

        String uri = httpServletRequest.getRequestURI();
        if(filterPath.contains(uri)){
            return null;
        }

        String token = httpServletRequest.getHeader("token");

        if(token != null){
            commonFeign.tokenVerify(token);
        }

        return null;
    }
}
