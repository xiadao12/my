package com.bluethink.cloudfeign.service;


import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.model.User;
import com.github.pagehelper.PageInfo;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
public interface UserService {
    /**
     * 新增用户
     * @param user
     */
    public Boolean create(User user)  ;

    /**
     * 获取用户
     * @return
     */
    public PageInfo<User> query(UserFilter userFilter)  ;

    /**
     * 登陆返回token
     * @return
     * @
     */
    public String login(String username, String password) ;
}
