package com.bluethink.cloudfeign.feign;

import com.bluethink.cloudserviceplugin.filter.PluginFilter;
import com.bluethink.cloudserviceplugin.model.Plugin;
import com.github.pagehelper.PageInfo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/11设计并构建初始版本v1.0.0
 */
@FeignClient(value = "service-plugin")
public interface PluginFeign {

    @PostMapping(value="/plugin/save")
    public Integer save(@RequestBody Plugin plugin) ;

    @PostMapping(value="/plugin/query")
    public PageInfo<Plugin> query(PluginFilter pluginFilter) ;

    @PostMapping("/plugin/update")
    public Boolean update(@RequestBody Plugin plugin) ;

    @PostMapping("/plugin/delete")
    public Boolean delete(@RequestParam("id") Integer id) ;

}
