package com.bluethink.cloudfeign.service.impl;

import com.bluethink.cloudfeign.feign.CommonFeign;
import com.bluethink.cloudserviceplugin.filter.PluginFilter;
import com.bluethink.cloudserviceplugin.model.Plugin;
import com.bluethink.cloudfeign.feign.PluginFeign;
import com.bluethink.cloudfeign.service.PluginService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Service;

import java.util.HashSet;


/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Service
@CacheConfig(cacheNames="pluginCache")
public class PluginServiceImpl implements PluginService {

    @Autowired
    PluginFeign pluginFeign;

    @Autowired
    private CommonFeign commonFeign;

    @Override
    public Boolean save(String token, Plugin plugin)  {
        Integer userId = commonFeign.tokenGetUserId(token);
        plugin.setUserId(userId);
        return pluginFeign.save(plugin) > 0;

    }

    @Override
    public PageInfo<Plugin> query(PluginFilter pluginFilter)  {
        PageInfo<Plugin> pageInfo = pluginFeign.query(pluginFilter);
        return pageInfo;
    }

    @Override
    public Boolean update(String token, Plugin plugin)  {
        judgeCurrentUser(token,plugin.getId());
        return pluginFeign.update(plugin);
    }

    @Override
    public Boolean delete(String token, Integer id)  {
        judgeCurrentUser(token,id);
        return pluginFeign.delete(id);
    }

    private void judgeCurrentUser(String token,Integer id){

        Integer userId = commonFeign.tokenGetUserId(token);

        if(userId == null){
            throw new RuntimeException("Token有误");
        }

        PluginFilter pluginFilter = new PluginFilter();
        HashSet<Integer> ids = new HashSet();
        ids.add(id);
        pluginFilter.setIds(ids);
        PageInfo<Plugin> pageInfo = query(pluginFilter);
        if(pageInfo != null && pageInfo.getList()!=null && pageInfo.getList().size() > 0){
            Plugin plugin = pageInfo.getList().get(0);
            if(plugin != null){
                Integer queryUserId = plugin.getUserId();
                if(queryUserId != null && queryUserId.equals(userId)){
                    return;
                }
            }
        }

        throw new RuntimeException("无权操作");
    }
}
