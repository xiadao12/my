package com.bluethink.cloudfeign.controller;

import com.bluethink.cloudfeign.service.PluginService;
import com.bluethink.cloudserviceplugin.filter.PluginFilter;
import com.bluethink.cloudserviceplugin.model.Plugin;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@RestController
@RequestMapping("/plugin")
@CrossOrigin
public class PluginController {

    @Autowired
    PluginService pluginService;

    @PostMapping(value="/save")
    public Boolean save(@RequestHeader("token") String token, @RequestBody Plugin plugin)  {
        return pluginService.save(token, plugin);
    }

    /**
     * 获取插件
     * @return
     */
    @PostMapping(value="/query")
    public PageInfo<Plugin> query(PluginFilter pluginFilter)  {
        return pluginService.query(pluginFilter);
    }

    /**
     * 更新插件
     * @param plugin
     */
    @PostMapping("/update")
    public Boolean update(@RequestHeader("token") String token, @RequestBody Plugin plugin)  {
        return pluginService.update(token, plugin);
    }

    /**
     * 删除插件
     */
    @PostMapping("/delete")
    public Boolean delete(@RequestHeader("token") String token, @RequestParam("id") Integer id)  {
        return pluginService.delete(token, id);
    }

}
