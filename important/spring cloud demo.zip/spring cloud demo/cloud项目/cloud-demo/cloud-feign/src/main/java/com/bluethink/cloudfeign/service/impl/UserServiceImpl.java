package com.bluethink.cloudfeign.service.impl;

import com.bluethink.cloudfeign.feign.CommonFeign;
import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.model.User;
import com.bluethink.cloudfeign.feign.UserFeign;
import com.bluethink.cloudfeign.service.UserService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserFeign userFeign;

    @Autowired
    private CommonFeign commonFeign;

    @Override
    public Boolean create(User user)  {

        Integer userId = userFeign.create(user);
        if(userId != null){
            return true;
        }
        return false;
    }

    @Override
    public PageInfo<User> query(UserFilter userFilter)  {

        //根据token来查询
        String token = userFilter.getToken();
        if(token != null){
            Integer userId = commonFeign.tokenGetUserId(token);
            if(userId != null){
                HashSet userIdSet = new HashSet();
                userIdSet.add(userId);
                userFilter.setIds(userIdSet);
            }
        }

        PageInfo<User> pageInfo = userFeign.query(userFilter);

        return pageInfo;

    }

    @Override
    public String login(String username,String password)  {
        String token = userFeign.login(username,password);
        return token;
    }

}
