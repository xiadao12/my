package com.bluethink.cloudservicecommon.controller;

import com.bluethink.cloudservicecommon.service.TokenService;
import com.netflix.discovery.converters.Auto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/13设计并构建初始版本v1.0.0
 */
@RestController
@CrossOrigin
@RequestMapping("/token")
public class TokenController {

    @Autowired
    TokenService tokenService;

    /**
     * 生成Token
     */
    @PostMapping("/create")
    public String create(@RequestParam("userId") Integer userId){
        return tokenService.create(userId);
    }

    /**
     * 根据token获取用户id
     */
    @PostMapping("/getUserId")
    public Integer getUserId(@RequestParam("token") String token){
        return tokenService.getUserId(token);
    }

    /**
     * 验证令牌
     */
    @PostMapping("/verify")
    public Integer verify(@RequestParam("token") String token){
        return tokenService.verify(token);
    }
}
