package com.bluethink.cloudservicecommon.service.impl;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.bluethink.cloudservicecommon.service.TokenService;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/13设计并构建初始版本v1.0.0
 */
@Service
public class TokenServiceImpl implements TokenService {


    private static final String ISSUER = "http://www.bluethink.cn";
    private static final long TTLMillis = 1000 * 60 * 60 * 3;
    //private static final long TTLMillis = 1000;

    //用于存放加密,<userId,secret>
    private static Map<Integer, String> secretMap;
    //用户存放token,<userId,token>
    //private static Map<Integer, String> tokenMap;

    static {
        secretMap = new HashMap<>();
        //tokenMap = new HashMap<>();
    }

    /**
     * 生成Token
     */
    @Override
    public String create(Integer userId){

        String token = null;
        Map<String, Object> payload = new HashMap<>();
        payload.put("userId", userId);

        String secret = UUID.randomUUID().toString();

        secretMap.put(userId, secret);

        long nowMillis = System.currentTimeMillis();
        long expMillis = nowMillis + TTLMillis;

        String TYPE = "JWT";
        String ALGORITHM = "HS256";
        Algorithm algorithm = Algorithm.HMAC256(secret);
        token = JWT.create()
                .withClaim("typ",TYPE)
                .withClaim("alg",ALGORITHM)
                .withHeader(payload)
                .withIssuer(ISSUER)
                .withIssuedAt(new Date(nowMillis))
                .withNotBefore(new Date(nowMillis))
                .withExpiresAt(new Date(expMillis))
                .sign(algorithm);

        //tokenMap.put(userId, token);

        return token;
    }

    /**
     * 根据token获取用户id
     */
    @Override
    public Integer getUserId(String token){
        return verify(token);
    }

    /**
     * 验证令牌
     */
    @Override
    public Integer verify(String token){

        try{
            //先解码获取用户id
            DecodedJWT decodedJWT = JWT.decode(token);
            if(decodedJWT != null){
                Claim decodedClaim = decodedJWT.getHeaderClaim("userId");
                Integer userId = decodedClaim.asInt();
                if(userId != null){
                    //根据用户id来获取加密的密钥
                    String secret = secretMap.get(userId);
                    if(secret != null){
                        //验证token
                        Algorithm algorithm = Algorithm.HMAC256(secret);
                        if(algorithm != null){
                            JWTVerifier verifier = JWT.require(algorithm)
                                    .withIssuer(ISSUER)
                                    .acceptExpiresAt(TTLMillis / 1000)
                                    .build();
                            if(verifier != null){
                                DecodedJWT jwt = verifier.verify(token);
                                return userId;
                            }
                        }
                    }
                }
            }
        }catch (TokenExpiredException e){
            throw new RuntimeException("令牌已失效，请重新登陆");
        }catch (Exception e){
            throw new RuntimeException("用户Token验证未通过，请重新登陆");
        }

        throw new RuntimeException("用户Token验证未通过");
    }
}
