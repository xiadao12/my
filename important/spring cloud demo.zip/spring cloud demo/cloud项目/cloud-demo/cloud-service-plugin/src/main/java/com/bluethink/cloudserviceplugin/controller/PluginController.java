package com.bluethink.cloudserviceplugin.controller;

import com.bluethink.cloudserviceplugin.filter.PluginFilter;
import com.bluethink.cloudserviceplugin.model.Plugin;
import com.bluethink.cloudserviceplugin.service.PluginService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@RestController
@RequestMapping("/plugin")
@CrossOrigin
public class PluginController {

    @Autowired
    PluginService pluginService;
    
    @PostMapping(value="/save")
    public Integer save(@RequestBody Plugin plugin)  {
        return pluginService.save(plugin);
    }
    
    /**
     * 获取插件
     * @return
     */
    @PostMapping(value="/query")
    public PageInfo<Plugin> query(@RequestBody PluginFilter pluginFilter)  {
        return pluginService.query(pluginFilter);
    }
    
    /**
     * 更新插件
     * @param plugin
     */
    @PostMapping("/update")
    public Boolean update(@RequestBody Plugin plugin)  {
        return pluginService.update(plugin);
    }
    
    /**
     * 删除插件
     * @param id
     */
    @PostMapping("/delete")
    public Boolean delete(@RequestParam("id") Integer id)  {
        
        return pluginService.delete(id);
    }
    
}
