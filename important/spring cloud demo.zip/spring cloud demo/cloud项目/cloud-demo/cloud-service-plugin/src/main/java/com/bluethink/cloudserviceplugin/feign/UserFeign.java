package com.bluethink.cloudserviceplugin.feign;

import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.model.User;
import com.github.pagehelper.PageInfo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/11设计并构建初始版本v1.0.0
 */
@FeignClient(value = "service-user")
public interface UserFeign {

    @PostMapping(value="/user/create")
    Integer create(@RequestBody User user);

    @PostMapping("/user/login")
    String login(@RequestParam("username") String username, @RequestParam("password") String password);

    @PostMapping(value="/user/query")
    PageInfo<User> query(@RequestBody UserFilter userFilter);

}
