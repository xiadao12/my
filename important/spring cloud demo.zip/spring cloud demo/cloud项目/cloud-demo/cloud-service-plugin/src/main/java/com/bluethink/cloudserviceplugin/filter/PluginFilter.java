package com.bluethink.cloudserviceplugin.filter;

import java.util.HashSet;

/**
 * @author 苏州中科蓝迪公司所有(c)2016-2021
 * @version 1.0.0
 * @brief 数据协同处理平台（DCPP）
 * @note 修订历史：1、yang zhou chuan 于2018/9/12设计并构建初始版本v1.0.0
 */
public class PluginFilter {
    private HashSet<Integer> ids;
    private Integer userId;
    private String name;
    private String tags;
    private int pageNum = 0;
    private int pageSize = 0;

    public HashSet<Integer> getIds() {
        return ids;
    }

    public void setIds(HashSet<Integer> ids) {
        this.ids = ids;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
