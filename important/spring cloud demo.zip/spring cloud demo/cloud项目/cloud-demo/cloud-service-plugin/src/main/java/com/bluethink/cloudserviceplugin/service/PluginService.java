package com.bluethink.cloudserviceplugin.service;


import com.bluethink.cloudserviceplugin.filter.PluginFilter;
import com.bluethink.cloudserviceplugin.model.Plugin;
import com.github.pagehelper.PageInfo;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
public interface PluginService {
    /**
     * 新增插件
     * @param plugin
     * @
     */
    public Integer save(Plugin plugin) ;
    
    /**
     * 根据id获取插件
     * @return
     */
    public PageInfo<Plugin> query(PluginFilter pluginFilter)  ;
    
    /**
     * 根据id更新插件
     * @param plugin
     */
    public Boolean update(Plugin plugin)  ;
    
    /**
     * 根据id删除插件
     * @param id
     */
    public Boolean delete(Integer id)  ;
}
