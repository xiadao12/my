package com.bluethink.cloudserviceplugin.service.impl;

import com.bluethink.cloudserviceplugin.feign.UserFeign;
import com.bluethink.cloudserviceplugin.filter.PluginFilter;
import com.bluethink.cloudserviceplugin.mapper.PluginMapper;
import com.bluethink.cloudserviceplugin.model.Plugin;
import com.bluethink.cloudserviceplugin.service.PluginService;
import com.bluethink.cloudserviceuser.filter.UserFilter;
import com.bluethink.cloudserviceuser.model.User;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;


/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Service
@CacheConfig(cacheNames="pluginCache")
public class PluginServiceImpl implements PluginService {

    @Autowired
    PluginMapper pluginMapper;

    @Autowired
    UserFeign userFeign;

    @Override
    public Integer save(Plugin plugin)  {
        return pluginMapper.save(plugin);

    }

    @Override
    public PageInfo<Plugin> query(PluginFilter pluginFilter)  {
        PageHelper.startPage(pluginFilter.getPageNum(), pluginFilter.getPageSize());
        Page<Plugin> page = (Page<Plugin>) pluginMapper.query(pluginFilter);
        PageInfo<Plugin> pageInfo = new PageInfo<>(page);


        if(pageInfo != null){
            List<Plugin> pluginList = pageInfo.getList();
            if(pluginList != null && pluginList.size() > 0){
                //先获取到所有的user
                List<Integer> userIdList = pluginList.stream().map(u -> u.getUserId()).collect(Collectors.toList());
                HashSet<Integer> userIdSet = new HashSet<>(userIdList);
                UserFilter userFilter = new UserFilter();
                userFilter.setIds(userIdSet);
                PageInfo<User> userPageInfo = userFeign.query(userFilter);

                HashMap<Integer, User> userMap = new HashMap<>();
                if(userPageInfo != null){
                    List<User> userList = userPageInfo.getList();
                    if(userList != null && userList.size() > 0){
                        userList.stream().forEach(u -> {
                            if(u.getId() != null){
                                userMap.put(u.getId(),u);
                            }
                        });
                    }
                }

                //加载User
                for(Plugin plugin : pluginList){
                    Integer userId = plugin.getUserId();
                    if(userId != null){
                        plugin.setUser(userMap.get(userId));
                    }
                }
            }
        }


        return pageInfo;
    }

    @Override
    public Boolean update(Plugin plugin)  {
        return pluginMapper.update(plugin) > 0;
    }

    @Override
    public Boolean delete(Integer id)  {
        return pluginMapper.delete(id) > 0;
    }
}
