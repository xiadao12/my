/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50713
Source Host           : localhost:3306
Source Database       : db_resource

Target Server Type    : MYSQL
Target Server Version : 50713
File Encoding         : 65001

Date: 2018-09-14 15:04:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_plugin
-- ----------------------------
DROP TABLE IF EXISTS `t_plugin`;
CREATE TABLE `t_plugin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `icon` varchar(200) DEFAULT NULL,
  `vsersion` varchar(100) DEFAULT NULL,
  `tags` varchar(200) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `url` varchar(1024) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `del_flag` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_plugin
-- ----------------------------
INSERT INTO `t_plugin` VALUES ('1', '1', '音乐播放器11', '修改图标', '修改版本', '修改tags', '修改描述', null, '2018-07-09 15:06:40', '2018-07-13 08:46:32', null);
INSERT INTO `t_plugin` VALUES ('2', '2', '33', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-09 15:06:41', '2018-09-14 10:31:12', null);
INSERT INTO `t_plugin` VALUES ('6', '1', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 15:45:45', '2018-07-11 15:45:45', null);
INSERT INTO `t_plugin` VALUES ('7', '1', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 15:58:39', '2018-07-11 15:58:39', null);
INSERT INTO `t_plugin` VALUES ('8', '1', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:01:43', '2018-07-11 16:01:43', null);
INSERT INTO `t_plugin` VALUES ('9', '1', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:03:03', '2018-07-11 16:03:03', null);
INSERT INTO `t_plugin` VALUES ('10', '1', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:03:53', '2018-07-11 16:03:53', null);
INSERT INTO `t_plugin` VALUES ('11', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:03', '2018-07-11 16:04:03', null);
INSERT INTO `t_plugin` VALUES ('12', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:26', '2018-07-11 16:04:26', null);
INSERT INTO `t_plugin` VALUES ('13', '2', '媒体播放', '4', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:27', '2018-07-11 17:08:02', null);
INSERT INTO `t_plugin` VALUES ('14', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:28', '2018-07-11 16:04:28', null);
INSERT INTO `t_plugin` VALUES ('15', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:29', '2018-07-11 16:04:29', null);
INSERT INTO `t_plugin` VALUES ('16', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:29', '2018-07-11 16:04:29', null);
INSERT INTO `t_plugin` VALUES ('17', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:29', '2018-07-11 16:04:29', null);
INSERT INTO `t_plugin` VALUES ('18', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:30', '2018-07-11 16:04:30', null);
INSERT INTO `t_plugin` VALUES ('19', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:30', '2018-07-11 16:04:30', null);
INSERT INTO `t_plugin` VALUES ('20', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:30', '2018-07-11 16:04:30', null);
INSERT INTO `t_plugin` VALUES ('21', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:30', '2018-07-11 16:04:30', null);
INSERT INTO `t_plugin` VALUES ('22', '2', '媒体播放', 'd:/abc', '2.0', 'tagssss', '这是一个媒体插件', null, '2018-07-11 16:04:49', '2018-07-11 16:04:49', null);
INSERT INTO `t_plugin` VALUES ('24', null, '369', 'string', null, 'string', 'string', null, '2018-09-12 15:41:01', '2018-09-12 15:46:22', null);
INSERT INTO `t_plugin` VALUES ('25', '1', '测试插件', 'a.jpg', '2.1', '标签', '不错', null, '2018-09-14 10:29:53', '2018-09-14 10:29:53', null);

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `password` varchar(255) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `avatar` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signature` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `del_flag` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'aaa', '李四', 'lisi222', 'mr li22', '12345@qq.com222', '签名22', '2018-07-09 15:03:01', '2018-09-12 11:28:41', null);
INSERT INTO `t_user` VALUES ('2', 'aaa', '李四12222', 'lisi222', 'mr li22', '12345@qq.com222', '签名22', '2018-07-09 15:03:02', '2018-09-12 09:54:57', null);
INSERT INTO `t_user` VALUES ('3', 'aaa', '修改姓名33', '修改昵称', '修改avatar', '修改邮箱', '修改签名', '2018-07-09 15:03:02', '2018-09-12 09:54:58', null);
INSERT INTO `t_user` VALUES ('16', 'aaa', 'string', 'string', 'string', 'string', 'string', '2018-09-11 18:21:00', '2018-09-12 09:54:59', null);
INSERT INTO `t_user` VALUES ('17', 'aaa', 'string', 'string', 'string', 'string', 'string', '2018-09-11 18:22:22', '2018-09-12 09:55:00', null);
INSERT INTO `t_user` VALUES ('18', 'aaa', 'string', 'string', 'string', 'string', 'string', '2018-09-12 08:47:05', '2018-09-12 09:55:02', null);
INSERT INTO `t_user` VALUES ('19', 'string', 'string', 'string', 'string', 'string', 'string', '2018-09-12 10:43:01', '2018-09-12 10:43:01', null);
INSERT INTO `t_user` VALUES ('20', 'string', 'string', 'string', 'string', 'string', 'string', '2018-09-12 11:04:38', '2018-09-12 11:04:38', null);
INSERT INTO `t_user` VALUES ('21', 'string', 'string', 'string', 'string', 'string', 'string', '2018-09-12 11:04:53', '2018-09-12 11:04:53', null);
INSERT INTO `t_user` VALUES ('22', '123', '水了', '水了的昵称', 'aaaa.jpg', '888@qq.com', '签名', '2018-09-14 10:05:26', '2018-09-14 10:05:26', null);
