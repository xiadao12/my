package com.bluethink.conf;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import com.github.pagehelper.PageInterceptor;

@Configuration
@MapperScan(basePackages = {"com.bluethink.mapper2"},sqlSessionTemplateRef = "sessionTemplate2")
public class DataSourceConfiguration2 {
    
    @Bean(name = "dataSource2")
    @ConfigurationProperties(prefix = "mysql2")
    public DataSource dataSource2() {
        return DataSourceBuilder.create().type(com.mchange.v2.c3p0.ComboPooledDataSource.class).build();
    }
    
    @Bean
    public SqlSessionFactory sessionFactory2(
                @Qualifier("dataSource2") DataSource dataSource
            ) throws Exception{
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        //添加xml目录
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        bean.setMapperLocations(resolver.getResources("classpath*:com/bluethink/mapper2/*.xml"));
        
        //分页插件
        Interceptor interceptor = new PageInterceptor();
        Properties properties = new Properties();
        //方言
        properties.setProperty("helperDialect", "mysql");
        //该参数默认为false
        //设置为true时，会将RowBounds第一个参数offset当成pageNum页码使用
        //和startPage中的pageNum效果一样
        properties.setProperty("offsetAsPageNum", "true");
        //默认为false，设置为true时，使用RowBounds分页会进行count查询
        properties.setProperty("rowBoundsWithCount", "true");
        //分页合理化，启用设为true时，如果pageNum<1会查询第一页，如果pageNum>pages会查询最后一页
        //禁用设为false时，如果pageNum<1或pageNum>pages会返回空数据
        properties.setProperty("reasonable", "false");
        //支持通过 Mapper 接口参数来传递分页参数，默认值false
        properties.setProperty("supportMethodsArguments","true");
        //为了支持startPage(Object params)方法，
        //增加了一个`params`参数来配置参数映射，用于从Map或ServletRequest中取值
        //可以配置pageNum,pageSize,count,pageSizeZero,reasonable,不配置映射的用默认值
        properties.setProperty("params","pageNum=pageNumKey;pageSize=pageSizeKey;");
        interceptor.setProperties(properties);
        bean.setPlugins(new Interceptor[] {interceptor});
        
        return bean.getObject();
    }
    
    @Bean
    public SqlSessionTemplate sessionTemplate2(
                @Qualifier("sessionFactory2") SqlSessionFactory sqlSessionFactory
            ) throws Exception {
        SqlSessionTemplate template = new SqlSessionTemplate(sqlSessionFactory);
        return template;
    }
}
