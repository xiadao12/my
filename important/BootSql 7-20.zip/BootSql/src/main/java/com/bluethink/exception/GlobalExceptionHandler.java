package com.bluethink.exception;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.bluethink.util.BtResult;

@RestControllerAdvice
public class GlobalExceptionHandler {
    
    public BtResult handle(HttpServletRequest request,HttpServletResponse response,Exception ex) {
/*        String path = request.getRequestURI();
        String method = request.getMethod();*/
        String params = "";
        StringBuffer sb = new StringBuffer();
        
        Enumeration<String> parameterNames = request.getParameterNames();
        
        while(parameterNames.hasMoreElements()) {
            String key = parameterNames.nextElement();
            sb.append(key + "=" + request.getParameter(key)+"&");
        }
        
        if(sb != null && sb.length() > 0) {
            params = sb.substring(0, sb.length() - 1);
        }
        
        StackTraceElement[] traceElements = ex.getStackTrace();
        String[] exceptions = new String[traceElements.length];
        for(int i=0;i<traceElements.length;i++) {
            exceptions[i] = traceElements[i].toString();
        }
        return BtResult.ERROR(exceptions);
    }
    
}
