package com.bluethink.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.bluethink.model.Plugin;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Mapper
public interface PluginMapper {
    /**
     * 新增插件
     * @param plugin
     */
    public Integer save(Plugin plugin) throws Exception ;
    
    /**
     * 根据id获取插件
     * @param id
     * @return
     */
    public List<Plugin> query(
            @Param("id")Integer id,
            @Param("userId")Integer userId,
            @Param("name")String name,
            @Param("tags")String tags,
            @Param("pageNumKey")int pageNum,
            @Param("pageSizeKey") int pageSize
            ) throws Exception ;
    
    /**
     * 根据id更新插件
     * @param plugin
     */
    public Integer update(Plugin plugin) throws Exception ;
    
    /**
     * 根据id删除插件
     * @param id
     */
    public Integer delete(@Param("id")Integer id) throws Exception ;
    
}
