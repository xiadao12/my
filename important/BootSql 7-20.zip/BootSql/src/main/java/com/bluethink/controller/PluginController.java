package com.bluethink.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bluethink.model.Plugin;
import com.bluethink.service.PluginService;
import com.bluethink.util.BtResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Api(tags="Plugin Api",description="插件管理")
@RestController
@RequestMapping("/plugin")
@CrossOrigin
public class PluginController {

    @Autowired
    PluginService pluginService;
    
    /**
     * 新增插件
     * @param plugin
     */
    @ApiOperation("保存插件")
    @ApiImplicitParams({
        @ApiImplicitParam(name="userId",value="用户id",dataType="Integer",paramType="form"),
        @ApiImplicitParam(name="name",value="插件名",dataType="String",paramType="form"),
        @ApiImplicitParam(name="icon",value="插件图标",dataType="String",paramType="form"),
        @ApiImplicitParam(name="vsersion",value="插件版本",dataType="String",paramType="form"),
        @ApiImplicitParam(name="tags",value="插件标签",dataType="String",paramType="form"),
        @ApiImplicitParam(name="description",value="插件描述",dataType="String",paramType="form")
    })
    @PostMapping(value="/save")
    public BtResult save(Plugin plugin) throws Exception {
        if(pluginService.save(plugin).getId() > 0)
        {
            return BtResult.OK();
        }
        return BtResult.ERROR("保存失败");
    }
    
    /**
     * 获取插件
     * @return
     */
    @ApiOperation("查询插件")
    @ApiImplicitParams({
        @ApiImplicitParam(name="id",value="插件id",dataType="Integer",paramType="query"),
        @ApiImplicitParam(name="userId",value="用户id",dataType="Integer",paramType="query"),
        @ApiImplicitParam(name="name",value="插件名",dataType="String",paramType="query"),
        @ApiImplicitParam(name="tags",value="插件标签",dataType="String",paramType="query"),
        @ApiImplicitParam(name="pageNum",value="第几页",dataType="Integer",paramType="query"),
        @ApiImplicitParam(name="pageSize",value="每页显示数量",dataType="Integer",paramType="query"),
    })
    @GetMapping(value="/query")
    public BtResult query(
                Integer id,
                Integer userId,
                String name,
                String tags,
                Integer pageNum,
                Integer pageSize
            ) throws Exception {
        Object obj = pluginService.query(id,userId,name,tags,pageNum,pageSize);
        return BtResult.OK(obj);
    }
    
    /**
     * 更新插件
     * @param plugin
     */
    @ApiOperation("更新插件")
    @ApiImplicitParams({
        @ApiImplicitParam(name="userId",value="用户id",dataType="Integer",paramType="form"),
        @ApiImplicitParam(name="name",value="插件名",dataType="String",paramType="form"),
        @ApiImplicitParam(name="icon",value="插件图标",dataType="String",paramType="form"),
        @ApiImplicitParam(name="vsersion",value="插件版本",dataType="String",paramType="form"),
        @ApiImplicitParam(name="tags",value="插件标签",dataType="String",paramType="form"),
        @ApiImplicitParam(name="description",value="插件描述",dataType="String",paramType="form")
    })
    @PostMapping("/update")
    public BtResult update(Plugin plugin) throws Exception {
        if(pluginService.update(plugin) > 0)
        {
            return BtResult.OK();
        }
        return BtResult.ERROR("更新失败,需更新的数据有可能不存在");
    }
    
    /**
     * 删除插件
     * @param id
     */
    @ApiOperation("删除插件")
    @ApiImplicitParams({
        @ApiImplicitParam(name="id",value="插件id",dataType="Integer",paramType="form"),
    })
    @PostMapping("/delete")
    public BtResult deleteById(Integer id) throws Exception {
        
        if(id == null) {
            return BtResult.ERROR("未传入id，删除失败");
        }
        
        if(pluginService.delete(id) > 0)
        {
            return BtResult.OK();
        }
        
        return BtResult.ERROR("删除失败，需删除的记录可能不存在");
    }
    
}
