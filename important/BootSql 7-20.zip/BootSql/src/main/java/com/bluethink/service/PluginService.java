package com.bluethink.service;

import com.bluethink.model.Plugin;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
public interface PluginService {
    /**
     * 新增插件
     * @param plugin
     * @throws Exception 
     */
    public Plugin save(Plugin plugin) throws Exception;
    
    /**
     * 根据id获取插件
     * @param id
     * @return
     */
    public Object query(Integer id,Integer userId, String name,String tags,Integer pageNum,Integer pageSize) throws Exception ;
    
    /**
     * 根据id更新插件
     * @param plugin
     */
    public Integer update(Plugin plugin) throws Exception ;
    
    /**
     * 根据id删除插件
     * @param id
     */
    public Integer delete(Integer id) throws Exception ;
}
