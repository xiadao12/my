package com.bluethink.controller;

import java.util.HashMap;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.bluethink.annotation.MyLog;
import com.bluethink.model.User;
import com.bluethink.service.UserService;
import com.bluethink.util.BtResult;
import com.github.pagehelper.PageInfo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
@Api(tags="User Api",description="用户管理")
@RestController
@RequestMapping(value="/user")
@CrossOrigin
public class UserController {
    
    @Autowired
    UserService userService;
    
    /**
     * 添加用户
     */
    
    @ApiOperation("保存用户信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name="userName",value="用户名",dataType="String",paramType="form"),
        @ApiImplicitParam(name="nickName",value="用户昵称",dataType="String",paramType="form"),
        @ApiImplicitParam(name="avatar",value="用户头像",dataType="String",paramType="form"),
        @ApiImplicitParam(name="nickName",value="用户昵称",dataType="String",paramType="form"),
        @ApiImplicitParam(name="email",value="电子邮件",dataType="String",paramType="form"),
        @ApiImplicitParam(name="signature",value="个性签名",dataType="String",paramType="form")
    })
    @PostMapping("/save")
    public BtResult save(User user) throws Exception {
        if(userService.save(user)) {
            int userId = user.getId();
            Map<String,Integer> map = new HashMap<String,Integer>();
            map.put("id", userId);
            return BtResult.OK(map);
        }
        return BtResult.ERROR("保存失败");
    }
    
    /**
     * 获取用户
     * @throws Exception 
     */
    @ApiOperation("查询用户信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name="id",value="用户id",dataType="Integer",paramType="query"),
        @ApiImplicitParam(name="userName",value="用户名",dataType="String",paramType="query"),
        @ApiImplicitParam(name="nickName",value="用户昵称",dataType="String",paramType="query"),
        @ApiImplicitParam(name="pageNum",value="第几页",dataType="Integer",paramType="query"),
        @ApiImplicitParam(name="pageSize",value="每页的数量",dataType="Integer",paramType="query")
    })
    @GetMapping("/query")
    @MyLog
    public BtResult query(Integer id,
            String userName,
            String nickName,
            Integer pageNum,
            Integer pageSize
            ) throws Exception {
        
        PageInfo<User> obj = userService.query(id, userName, nickName, pageNum, pageSize);
        //userService.myTest();
        return BtResult.OK(obj);
    }
    
    /**
     * 更新用户
     * @param user
     */
    @ApiOperation("更新用户信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name="userName",value="用户名",dataType="String",paramType="form"),
        @ApiImplicitParam(name="nickName",value="用户昵称",dataType="String",paramType="form"),
        @ApiImplicitParam(name="avatar",value="用户头像",dataType="String",paramType="form"),
        @ApiImplicitParam(name="nickName",value="用户昵称",dataType="String",paramType="form"),
        @ApiImplicitParam(name="email",value="电子邮件",dataType="String",paramType="form"),
        @ApiImplicitParam(name="signature",value="个性签名",dataType="String",paramType="form")
    })
    @PostMapping("/update")
    public BtResult update(User user) throws Exception {
        if(userService.update(user) > 0)
        {
            return BtResult.OK();
        }
        return BtResult.ERROR("更新失败,需更新的记录有可能不存在");
    }
    
    /**
     * 删除用户
     * @param id
     * @PathVariable 
     */
    @ApiOperation("删除用户信息")
    @ApiImplicitParams({
        @ApiImplicitParam(name="id",value="用户id",dataType="Integer",paramType="form")
    })
    @PostMapping("/delete")
    public BtResult delete(Integer id) throws Exception {
        if(id == null) {
            return new BtResult(500,"未传入id，删除失败");
        }
        if(userService.delete(id) > 0)
        {
            return BtResult.OK();
        }
        return BtResult.ERROR("删除失败，需删除的记录可能不存在");
    }
}
