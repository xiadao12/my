package com.bluethink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableCaching
public class BootSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootSqlApplication.class, args);
	}
	
	/* @Bean
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer(Object.class));
        //这一步是必要的，表示：通知spring_boot_redis用我自己的序列化方式
        redisTemplate.afterPropertiesSet();
        return redisTemplate;
    }*/
}
