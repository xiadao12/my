package com.bluethink.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogAspect {
    
    @Pointcut("@annotation(com.bluethink.annotation.MyLog)")
    public void cut() {}
    
    @Before("cut()")
    public void before(JoinPoint joinPoint) {
        System.out.println("事前通知");
    }
    
    @Around("cut()")
    public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable{
        System.out.println("环绕通知开始");
        //获取参数内容
        Object[] args = proceedingJoinPoint.getArgs();
        
        //获取参数名称和类型
        Signature signature = proceedingJoinPoint.getSignature();
        MethodSignature methodSignature = (MethodSignature)signature;
        String[] paramNames = methodSignature.getParameterNames();
        Class<?>[] paramTypes = methodSignature.getParameterTypes();
        
        if(args != null) {
            for(int i=0;i<args.length;i++) {
                
                String paramName = paramNames[i];
                Class<?> paramType = paramTypes[i];
                
                Object obj = args[i];
                if(obj != null) {
                    System.out.println("参数类型:" + paramType + "  参数名:"+paramName+"  值为:" + obj.toString());
                }else {
                    System.out.println("参数类型:" + paramType + "  参数名:"+paramName+"  值为:null");
                }
                
                
            }
        }
            
        //System.out.println(args.toString());
        return proceedingJoinPoint.proceed();
        //System.out.println("环绕通知结束");
    }
    
    @After("cut()")
    public void after() {
        System.out.println("事后通知");
    }
}
