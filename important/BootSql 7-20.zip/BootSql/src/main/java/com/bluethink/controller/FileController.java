package com.bluethink.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bluethink.util.BtResult;
import com.bluethink.util.FileUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(tags="File Api",description="文件管理")
@RestController
@RequestMapping("/file")
@CrossOrigin
public class FileController {
    
    @Value("${file.rootPath}")
    private String rootPath;
    
    @ApiOperation("上传文件")
    @ApiImplicitParams({
        @ApiImplicitParam(name="category",value="文件类型",dataType="String",paramType="form")
    })
    @PostMapping("/{category}")
    public BtResult upload(@PathVariable("category") String category, 
            @RequestParam("file")MultipartFile file) throws Exception {
        //相对路径
        String relativePath = FileUtil.uploadFile(file, category, rootPath);
        return BtResult.OK(relativePath);
    }
    
    @ApiOperation("下载文件")
    @ApiImplicitParams({
        @ApiImplicitParam(name="category",value="文件类型",dataType="String",paramType="form"),
        @ApiImplicitParam(name="fileName",value="文件名",dataType="String",paramType="form")
    })
    @GetMapping("/download")
    public void download(@RequestParam("url")String url,@RequestParam(value="name",required=false)String name,
            HttpServletResponse response) throws Exception {
        
        if(url != null && !"".equals(url))
        {
            FileUtil.download(rootPath,url,response,name);
        }
    }
}
