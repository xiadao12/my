package com.bluethink.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.UUID;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

public class FileUtil {
    /**
     * 上传文件
     * @param mFile
     * @param fileType
     * @param parentDir
     * @return
     * @throws Exception
     */
    public static String uploadFile(MultipartFile mFile,String category,String rootPath) throws Exception{
        String absolutePath = null;
        if(mFile != null && !mFile.isEmpty() && rootPath != null && !"".equals(rootPath)) {
            
            //获取文件类型
            FileType fileType = null;
            if(category.equals(Constant.FILE_STYLE_PLUGIN)) {
                fileType = FileType.COMPRESSED_FILE;
            }else if(category.equals(Constant.FILE_STYLE_AVATAR) || category.equals(Constant.FILE_STYLE_ICON)){
                fileType = FileType.PICTURE_FILE;
            }else {
                throw new RuntimeException("url请求地址有误");
            }
            
            //设置文件父路径
            String parentDir = rootPath + category;
            File saveDirectory = new File(parentDir);
            if(!saveDirectory.exists()) {
                saveDirectory.mkdirs();
            }
            
            //获取后缀名
            String originalName = mFile.getOriginalFilename();
            String suffix = originalName.substring(originalName.lastIndexOf(".")).toLowerCase();
            
            //判断文件类型
            if(!fileType.getSupportedType().contains(suffix)) {
                throw new RuntimeException(fileType.getMessage());
            }
            
            //使用UUID生成新的文件名，防止文件名重复
            String saveName = UUID.randomUUID().toString().replace("_", "") + suffix;
            //绝对路径
            absolutePath = parentDir + "/" + saveName;
            //保存文件
            mFile.transferTo(new File(absolutePath));
            
            //返回相对路径
            String relativePath = category + "/" + saveName;
            
            return relativePath;
        }
        return null;
    }
    
    public static void download(String rootPath,String absolutePath,HttpServletResponse response) throws Exception {
        download(rootPath,absolutePath, response, null);
    }
    
    public static void download(String rootPath,String url,HttpServletResponse response,String name) throws Exception {
        //文件的绝对路径
        String absolutePath = rootPath + url;
        File file = new File(absolutePath);
        if(file.exists() && file.isFile()) {
            //设置文件名
            String fileName = null;
            if(name != null && !"".equals(name)) {
                fileName = name;
            }else {
                fileName = url.substring(url.lastIndexOf("/")+1);
            }
            
            //判断文件所属种类 avatar,icon,plugin
            String fileStyle = url.substring(0,url.lastIndexOf("/"));
            
            //如果是插件则是下载，如果是头像或者图标则是加载
            if(fileStyle.equals(Constant.FILE_STYLE_PLUGIN)) {
                response.setContentType(new MimetypesFileTypeMap().getContentType(new File(fileName)));
                //response.setHeader("Content-Disposition","attachment;filename="+URLEncoder.encode(fileName, "UTF-8"));
                response.setHeader("Content-Disposition",URLEncoder.encode(fileName, "UTF-8"));
            }
            write(new FileInputStream(file),response.getOutputStream());
        }else {
            throw new RuntimeException("文件不存在");
        }
    }
    
    /**
     * 写入文件
     * @param in
     * @param out
     * @throws IOException
     */
    public static void write(FileInputStream in, ServletOutputStream out) throws IOException{
        try {
            byte[] buffer = new byte[1024];
            int len = -1;
            while((len = in.read(buffer)) != -1) {
                out.write(buffer,0,len);
            }
            out.flush();
        }finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }
    }
    
}
