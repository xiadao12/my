package com.bluethink.util;

/**
 * 定义常量
 * @author BlueThink
 *
 */
public class Constant {
    public static final String FILE_STYLE_AVATAR = "avatar";
    public static final String FILE_STYLE_ICON = "icon";
    public static final String FILE_STYLE_PLUGIN = "plugin";
}
