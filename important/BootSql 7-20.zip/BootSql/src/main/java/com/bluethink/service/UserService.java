package com.bluethink.service;

import com.bluethink.model.User;
import com.github.pagehelper.PageInfo;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
public interface UserService {
    /**
     * 新增用户
     * @param user
     */
    public Boolean save(User user) throws Exception ;
    
    /**
     * 获取用户
     * @param id
     * @return
     */
    public PageInfo<User> query(Integer id,String userName,String nickName,Integer pageNum,Integer pageSize) throws Exception ;
    
    /**
     * 更新用户
     * @param user
     */
    public Integer update(User user) throws Exception ;
    
    /**
     * 根据id删除用户
     * @param user
     */
    public Integer delete(Integer id) throws Exception ;
    
    public void myTest() throws Exception;
}
