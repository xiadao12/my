package com.bluethink.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.bluethink.model.User;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Mapper
public interface UserMapper {
    /**
     * 新增用户
     * @param user
     */
    public Integer save(User user) throws Exception ;
    
    /**
     * 查询用户
     * @param id
     * @return
     * @throws Exception
     */
    public List<User> query(
            @Param("id") Integer id, 
            @Param("userName") String userName, 
            @Param("nickName") String nickName,
            @Param("pageNumKey")int pageNum,
            @Param("pageSizeKey") int pageSize
            ) throws Exception;
    
    /**
     * 更新用户
     */
    public Integer update(User user) throws Exception ;
    
    /**
     * 根据id删除用户
     * @param user
     */
    public Integer delete(@Param("id") Integer id) throws Exception ;
}
