package com.bluethink.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bluethink.mapper.PluginMapper;
import com.bluethink.mapper2.PluginMapper2;
import com.bluethink.model.Plugin;
import com.bluethink.service.PluginService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 */
@Service
@CacheConfig(cacheNames="pluginCache")
public class PluginServiceImpl implements PluginService {

    @Autowired
    PluginMapper pluginMapper;
    @Autowired
    PluginMapper2 pluginMapper2;
    
    @Override
    @Transactional(rollbackFor=Exception.class)
    @CachePut
    public Plugin save(Plugin plugin) throws Exception {
        Integer id = pluginMapper.save(plugin);
        plugin.setId(id);
        return plugin;
    }

    @Override
    @Cacheable
    public PageInfo<Plugin> query(Integer id,Integer userId,String name,String tags,Integer pageNum,Integer pageSize) throws Exception {
            
            if(pageNum == null){
                pageNum = 0;
            }
            
            if(pageSize == null) {
                pageSize = 0;
            }
            
            Page<Plugin> page = (Page<Plugin>) pluginMapper.query(id, userId, name, tags, pageNum, pageSize);
            return page.toPageInfo();
            
/*            PageHelper.startPage(pageNum, pageSize);
            Page<Plugin> page = (Page<Plugin>) pluginMapper.query(id, userId, name, tags);
            PageInfo<Plugin> pageInfo = page.toPageInfo();
            return pageInfo;*/
    }
    
    @Override
    @CachePut(key="#p0.id")
    @Transactional(rollbackFor=Exception.class)
    public Integer update(Plugin plugin) throws Exception {
        return pluginMapper.update(plugin);
    }

    @Override
    @Cacheable
    @Transactional(rollbackFor=Exception.class)
    public Integer delete(Integer id) throws Exception {
        return pluginMapper.delete(id);
    }
}
