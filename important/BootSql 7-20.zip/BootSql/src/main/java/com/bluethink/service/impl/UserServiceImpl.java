package com.bluethink.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bluethink.annotation.MyLog;
import com.bluethink.mapper.UserMapper;
import com.bluethink.model.User;
import com.bluethink.service.UserService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * spring boot整合mybatis 苏州中科蓝迪公司所有(c)2016-2021 
 * @version 1.0.0
 * @author Danny于2018年7月3日创建
 * 
 */
@Service
public class UserServiceImpl implements UserService {
    
    @Autowired
    UserMapper userMapper;
    
    @Transactional(rollbackFor=Exception.class)
    @Override
    public Boolean save(User user) throws Exception {
        return userMapper.save(user) > 0;
    }

    @Override
    public PageInfo<User> query(Integer id, String userName, String nickName, Integer pageNum, Integer pageSize) throws Exception {
        if(pageNum == null) {
            pageNum = 0;
        }
        if(pageSize == null) {
            pageSize = 0;
        }
        
        //PageHelper.startPage(pageNum, pageSize);
        Page<User> page = (Page<User>) userMapper.query(id, userName, nickName, pageNum, pageSize);
        PageInfo<User> pageInfo = new PageInfo<>(page);
        
        return pageInfo;
    }
    
    @Override
    public Integer update(User user) throws Exception {
        return userMapper.update(user);
    }

    @Transactional(rollbackFor=Exception.class)
    @Override
    public Integer delete(Integer id) throws Exception {
        return userMapper.delete(id);
    }

    @Override
    @MyLog
    public void myTest() throws Exception {
        //System.out.println(name);
        System.out.println("进入myTest");
    }
}
