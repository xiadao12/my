
-- 如果数据库已存在则删除
drop database if exists db_resource;

create database db_resource;

use db_resource;

create table t_user (
    id bigint not null primary key auto_increment comment '主键id',
    user_name varchar(100),
    nick_name varchar(100),
    avatar varchar(200),
    email varchar(100),
    signature varchar(200),
    create_time datetime,
    update_time timestamp,
    del_flag smallint
);

create table t_plugin (
    id bigint not null primary key auto_increment,
    user_id bigint,
    name varchar(200),
    icon varchar(200),
    vsersion varchar(100),
    tags varchar(200),
    description varchar(1024),
    url varchar(1024),
    create_time datetime,
    update_time timestamp,
    del_flag smallint
);